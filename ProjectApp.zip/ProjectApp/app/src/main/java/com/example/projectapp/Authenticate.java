package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.w3c.dom.Text;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class Authenticate extends AppCompatActivity {

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults[0] == 0) {
            FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(Authenticate.this);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            fusedLocationProviderClient.getCurrentLocation(102, null)
                    .addOnSuccessListener(Authenticate.this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                EditText latt = findViewById(R.id.lat);
                                EditText lonn = findViewById(R.id.longitude);
                                latt.setText("" + String.format("%.2f", location.getLatitude()));
                                lonn.setText("" + String.format("%.2f", location.getLongitude()));
                                Log.v(" " + location.getLatitude(), "  " + location.getLongitude());
                            }
                        }
                    });
        } else if (grantResults[0] == -1){
            Log.v("Refuse", "  Refus");
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authenticate);

        Button sub = findViewById(R.id.submit);
        EditText ssid = findViewById(R.id.ssid);
        EditText pass = findViewById(R.id.pass);
        EditText lat = findViewById(R.id.lat);
        EditText lon = findViewById(R.id.longitude);
        EditText plant = findViewById(R.id.plant);

        Button butt = findViewById(R.id.butt);
        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("Clicked", "Ye" );
                FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(Authenticate.this);
                if (ActivityCompat.checkSelfPermission(Authenticate.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(Authenticate.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    String[] permissions = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
                    ActivityCompat.requestPermissions(Authenticate.this, permissions , 1 );
                    Log.v("Perhaps", " no permissions");
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
           }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Authenticate.this, "Success", Toast.LENGTH_LONG).show();

                OkHttpClient client = new OkHttpClient();
                String url = "http://192.168.4.1/POST/?NetworkSSID=" + ssid.getText() +
                        "&Password=" + pass.getText() +
                        "&latitude=" + lat.getText() +
                        "&longitude=" + lon.getText() +
                        "&plantType=" + plant.getText();
                Log.v("url:" , url);
                Request request = new Request.Builder()
                        .url(url)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        e.printStackTrace();
                        Log.v("Exception", " Caught");
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            Log.v("body: ", "" + response.code());
                            int code = response.code();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String result = "Unsuccessful";
                                    switch (code){
                                        case 200:
                                            result = "Success!";
                                            break;
                                        case 202:
                                            result = "Incorrect network credentials";
                                            break;
                                        case 203:
                                            result = "Incorrect location";
                                            break;
                                        case 201:
                                            result = "Incorrect plant type";
                                            break;
                                    }
                                    Toast.makeText(Authenticate.this, result, Toast.LENGTH_LONG).show();

                                }
                            });
                        }
                        Log.v("Exception", " UnCaught");
                    }
                });

                }
        });

    }
}