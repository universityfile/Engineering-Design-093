package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.OutOfQuotaPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String userID = "7cWQOnjeQ3NsElzEPQigpvmsIdL2";

        //set up WorkManager to perpetually check if system is working
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        PeriodicWorkRequest saveRequest = new PeriodicWorkRequest.Builder(NotificationWorker.class, 16, TimeUnit.MINUTES)
                .addTag("Error")
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(getApplicationContext()).enqueueUniquePeriodicWork("Garden Buddy Error", ExistingPeriodicWorkPolicy.KEEP, saveRequest);

        /*
        // this code is used for testing
        WorkRequest uploadWorkRequest =
                new OneTimeWorkRequest.Builder(NotificationWorker.class)
                        // Additional configuration

                        .build();
        WorkManager.getInstance().enqueue(uploadWorkRequest);
        */

        //query Firebase Realtime Database to retrieve data
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("UsersData/7cWQOnjeQ3NsElzEPQigpvmsIdL2/data/");

        TextView lastupdate = findViewById(R.id.lastupdate);
        TextView amount = findViewById(R.id.amount);
        TextView rain = findViewById(R.id.rain_today);
        TextView sensor = findViewById(R.id.sensor);


        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                String value= "" +dataSnapshot.getValue();
                Log.v("   String" , "  ::: "  + value);
                Query q = dataSnapshot.getRef().orderByChild("epoch").limitToLast(1);
                q.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String temp = "" + snapshot.getValue();
                        temp = temp.substring(1,11);
                        Log.v(" OPAAAA:  ", temp);
                        Log.v("LLLALLDLSA:  ", ""  + snapshot.child(temp).child("error").getValue());
                        lastupdate.setText("Last update: " + snapshot.child(temp).child("timeLocal").getValue());
                        amount.setText("Amount of water: " + snapshot.child(temp).child("water").getValue() + " litres");
                        rain.setText("Amount of rain: " + snapshot.child(temp).child("rain").getValue() + " mm");
                        sensor.setText("Sensor reading: " + (Float.parseFloat(snapshot.child(temp).child("moisture").getValue().toString()) * (-0.0416) + 125 ) + " %"  );
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                float total = 0;
                for (DataSnapshot childDoc : dataSnapshot.getChildren()) {
                    total = total + Float.parseFloat(childDoc.child("saved").getValue().toString());
                }
                Log.v("total is " , " " + total );
                TextView totalView = findViewById(R.id.totalSaved);
                totalView.setText("Total water saved: " + total + " litres");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.v("loadPost:onCancelled", "" +databaseError.toException());
            }
        };
        myRef.addValueEventListener(postListener);

    }
}

