package com.example.projectapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class NotificationWorker extends Worker {
    NotificationChannel channel;

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Errors";
            String description = "For errors";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            channel = new NotificationChannel("33", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getApplicationContext().getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public NotificationWorker(
            @NonNull Context context,
            @NonNull WorkerParameters params) {
        super(context, params);
    }

    public Result doWork() {
        createNotificationChannel();

        final boolean[] queryResult = {true};

        Log.d("NOTIFICATION ", "CREATED");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("UsersData/7cWQOnjeQ3NsElzEPQigpvmsIdL2/data/");

        ValueEventListener readingListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                String value = "" + dataSnapshot.getValue();
                Query q = dataSnapshot.getRef().orderByChild("epoch").limitToLast(1);
                q.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        queryResult[0]=true;
                        String temp = "" + snapshot.getValue();
                        temp = temp.substring(1, 11);
                        Log.v("document number:  ", temp);
                        Long tsLong = System.currentTimeMillis()/1000;
                        Log.v("Something",  ""+((boolean)snapshot.child(temp).child("error").getValue(true) == true));
                        Log.v( "Result::","  " + (snapshot.child(temp).child("error").getValue().toString() + "" == "true"));
                        if ((((boolean)snapshot.child(temp).child("error").getValue(true) == true)) || Long.parseLong(snapshot.child(temp).child("time").getValue().toString()) - tsLong > 28800) {

                            NotificationManagerCompat myManager = NotificationManagerCompat.from(getApplicationContext());
                            NotificationCompat.Builder Noti = new NotificationCompat.Builder(getApplicationContext());
                            Noti.setContentTitle("Garden Buddy Notification");
                            Noti.setContentText("A problem has occurred. Please check if container is full");
                            Noti.setSmallIcon(R.drawable.ic_launcher_foreground);
                            Noti.setChannelId("33");

                            myManager.notify(1, Noti.build());
                            Log.d("NOTIFICATION ", "SEEEEEEEEEEEEENT");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        queryResult[0] =false;
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                queryResult[0]=false;
                Log.v("loadPost:onCancelled", "" + databaseError.toException());
            }
        };
        myRef.addValueEventListener(readingListener);
        if (queryResult[0] == false) {
            return Result.failure();
        } else {
            return Result.success();
        }
    }
}
